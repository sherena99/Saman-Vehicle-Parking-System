package model;

public class Main {
    public static void main(String[] args) {
        Van v1 = new Van();

        v1.park("ca-20", "van");
        v1.park("ca-212", "van");

    }
}
